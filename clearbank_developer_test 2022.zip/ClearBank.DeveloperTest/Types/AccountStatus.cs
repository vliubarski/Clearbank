﻿namespace ClearBank.DeveloperTest.Types
{
    public enum AccountStatus
    {
        Live,
        Disabled,
        InboundPaymentsOnly
    }
}
